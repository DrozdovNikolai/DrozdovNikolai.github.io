package com.example.pod_3.data

data class FacultyList(
    var items : MutableList<Faculty> = mutableListOf()
)
