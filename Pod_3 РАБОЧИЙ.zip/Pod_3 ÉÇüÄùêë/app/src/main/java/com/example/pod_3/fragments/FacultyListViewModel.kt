package com.example.pod_3.fragments

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import com.example.pod_3.data.Faculty
import com.example.pod_3.data.FacultyList
import com.example.pod_3.repository.UniversityRepository

class FacultyListViewModel : ViewModel() {
    var facultyList: MutableLiveData<FacultyList?> = MutableLiveData()

    private var _faculty: Faculty?=null

    val faculty
        get() = _faculty

    val university
        get()= UniversityRepository.getInstance().university.value

    private val facultyListObserver = Observer<List<Faculty>> {
            list ->
        facultyList.postValue(FacultyList().apply {
            items=list.filter { it.universityID==university?.id } as MutableList<Faculty>
        })
    }

    init {
        UniversityRepository.getInstance().facultyList.observeForever(facultyListObserver)

        UniversityRepository.getInstance().faculty.observeForever {
            _faculty=it
        }
    }

    fun deleteFaculty() {
        if (faculty!=null)
            UniversityRepository.getInstance().deleteFaculty(faculty!!)
    }

    fun appendFaculty(facultyName: String) {

        val faculty = Faculty()
        faculty.name=facultyName
        faculty.universityID=university?.id
        UniversityRepository.getInstance().newFaculty((faculty))
    }

    fun updateFaculty(facultyName: String) {
        if (_faculty != null) {
            _faculty!!.name = facultyName
            UniversityRepository.getInstance().updateFaculty(_faculty!!)
        }
    }

    fun setCurrentFaculty(faculty: Faculty){
        UniversityRepository.getInstance().setCurrentFaculty(faculty)
    }
}