package com.example.pod_3.data

data class UniversityList(
    var items: MutableList<University> = mutableListOf()
)
