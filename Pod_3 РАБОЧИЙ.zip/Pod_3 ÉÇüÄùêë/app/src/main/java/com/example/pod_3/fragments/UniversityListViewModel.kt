package com.example.pod_3.fragments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import com.example.pod_3.data.University
import com.example.pod_3.data.UniversityList
import com.example.pod_3.repository.UniversityRepository

class UniversityListViewModel : ViewModel() {
    // TODO: Implement the ViewModel

    //var universityList: MutableLiveData<UniversityList> = MutableLiveData()
    val universityList: LiveData<List<University>> = UniversityRepository.getInstance().universityList
    private var _university: University?=null

    val university
        get() = _university


    init {
     //   UniversityRepository.getInstance().universityList.observeForever(universityListObserver)

        UniversityRepository.getInstance().university.observeForever {
            _university=it
        }
    }

    fun deleteUniversity() {
        if (university!=null)
            UniversityRepository.getInstance().deleteUniversity(university!!)
    }

    fun appendUniversity(universityName: String, universityCity: String) {

        val university = University()
        university.name=universityName
        university.city=universityCity
        UniversityRepository.getInstance().newUniversity((university))
    }

    fun updateUniversity(universityName: String, universityCity: String) {
        if (_university != null) {
            _university!!.name = universityName
            _university!!.city = universityCity
            UniversityRepository.getInstance().updateUniversity(_university!!)
        }
    }

    fun setCurrentUniversity(university: University){
        UniversityRepository.getInstance().setCurrentUniversity(university)
    }








}