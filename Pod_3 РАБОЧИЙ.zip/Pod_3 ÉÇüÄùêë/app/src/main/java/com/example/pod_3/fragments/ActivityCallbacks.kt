package com.example.pod_3.fragments

import com.example.pod_3.data.Student

interface ActivityCallbacks {
    fun updateTitle(newTitle: String)
    fun setFragment(fragmentID: Int, student: Student?=null)
}