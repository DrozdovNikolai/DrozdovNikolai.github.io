package com.example.pod_3

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModelProvider.NewInstanceFactory.Companion.instance
import com.example.pod_3.repository.UniversityRepository

class Application35_1 : Application() {

    override fun onCreate(){
        super.onCreate()
       // UniversityRepository.getInstance().loadData()
    }

    init {
        instance = this
    }

    companion object{
        private var instance: Application35_1? = null

        val context
            get()=applicationContext()

        private fun applicationContext() : Context {
            return instance!!.applicationContext
        }
    }
}