package com.example.pod_3.fragments

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.pod_3.data.Group
import com.example.pod_3.data.Student
import com.example.pod_3.repository.UniversityRepository
import java.util.Date

class StudentsViewModel : ViewModel() {
    var studentList: MutableLiveData<List<Student>> = MutableLiveData()

    private var _student : Student? = null
    val student
        get()=_student

    var group : Group? = null

    fun set_Group(group: Group){
        this.group=group
        UniversityRepository.getInstance().listOfStudent.observeForever{
            studentList.postValue(
                it.filter { it.groupID == group.id } as MutableList<Student>
            )
        }
        UniversityRepository.getInstance().student.observeForever{
            _student=it
        }
    }

    fun deleteStudent(){
        if (student!=null)
            UniversityRepository.getInstance().deleteStudent(student!!)
    }

    fun appendStudent(lastName : String, firstname : String, middleName : String, birthDate : Date, phone :String){
        val student= Student()
        student.lastName=lastName
        student.firstName=firstname
        student.middleName=middleName
        student.birthDate=birthDate
        student.phone=phone
        student.groupID=group!!.id
        UniversityRepository.getInstance().addStudent(student)
    }

    fun updateStudent(lastName: String,firstname: String,middleName: String,birthDate: Date,phone: String){
        if (_student!=null){
            _student!!.lastName=lastName
            _student!!.firstName=firstname
            _student!!.middleName=middleName
            _student!!.birthDate=birthDate
            _student!!.phone=phone
            UniversityRepository.getInstance().updateStudent(_student!!)
        }
    }

    fun setCurrentStudent(student: Student){
        UniversityRepository.getInstance().setCurrentStudent(student)
    }
}