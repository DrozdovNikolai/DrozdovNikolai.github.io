package com.example.pod_3.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.preference.Preference
import androidx.preference.PreferenceManager
import com.example.pod_3.Application35_1
import com.example.pod_3.data.University
import com.example.pod_3.data.UniversityList
import com.google.gson.Gson
import com.example.pod_3.R
import com.example.pod_3.data.Faculty
import com.example.pod_3.data.FacultyList
import com.example.pod_3.data.Group
import com.example.pod_3.data.Student
import com.example.pod_3.database.UniversityDB
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch


const val TAB="com.example.pod_3.TAG.repository"

class UniversityRepository private constructor() {

    companion object {
        private var INSTANCE: UniversityRepository? = null

        fun getInstance(): UniversityRepository {
            if (INSTANCE == null) {
                INSTANCE = UniversityRepository()
            }
            return INSTANCE ?: throw IllegalStateException("Universrepo isn't initialized")
        }
    }


    var university: MutableLiveData<University?> = MutableLiveData()


    fun setCurrentUniversity(_university: University) {
        university.postValue(_university)
    }

    fun setCurrentUniversity(position: Int) {
        if (universityList.value == null || position < 0 || universityList.value?.size!! <= position)
            return
        setCurrentUniversity(universityList.value!![position])
    }

    fun getUniversityPosition(university: University): Int = universityList.value?.indexOfFirst {
        it.id == university.id
    } ?: -1

    fun getUniversityPosition() = getUniversityPosition(university.value ?: University())


    var faculty: MutableLiveData<Faculty?> = MutableLiveData()


    fun setCurrentFaculty(_faculty: Faculty) {
        faculty.postValue(_faculty)
    }

    fun setCurrentFaculty(position: Int) {

        if (facultyList.value == null || position < 0 || facultyList.value?.size!! <= position)
            return
        setCurrentFaculty(facultyList.value!![position])
    }

    fun getFacultyPosition(faculty: Faculty): Int = facultyList.value?.indexOfFirst{
        it.id == faculty.id
    } ?: -1

    fun getFacultyPosition() = getFacultyPosition(faculty.value ?: Faculty())


    private val universityDB by lazy {
        DBRepository(UniversityDB.getDatabase(Application35_1.context).universityDAO())
    }

    private val myCoroutineScope = CoroutineScope(Dispatchers.Main)

    fun onDestroy() {
        myCoroutineScope.cancel()
    }

    val universityList: LiveData<List<University>> = universityDB.getUniversities()
        .asLiveData()

    fun newUniversity(university: University) {
        myCoroutineScope.launch {
            universityDB.insertUniversity(university)
            setCurrentUniversity(university)
        }
    }

    fun updateUniversity(university: University) {
        myCoroutineScope.launch {
            universityDB.updateUniversity(university)
        }
    }

    fun deleteUniversity(university: University) {
        myCoroutineScope.launch {
            universityDB.deleteUniversity(university)
            setCurrentUniversity(0)
        }
    }

    val facultyList: LiveData<List<Faculty>> = universityDB.getAllFaculties().asLiveData()

    fun newFaculty(faculty: Faculty) {
        myCoroutineScope.launch {
            universityDB.insertFaculty(faculty)
            setCurrentFaculty(faculty)
        }
    }

    fun updateFaculty(faculty: Faculty) {
        newFaculty(faculty)

    }

    fun deleteFaculty(faculty: Faculty) {
        myCoroutineScope.launch {
            universityDB.deleteFaculty(faculty)
            setCurrentFaculty(0)
        }
    }

    val listOfGroup: LiveData<List<Group>> = universityDB.getAllGroups().asLiveData()
    var listOfStudent: LiveData<List<Student>> = universityDB.getAllStudents().asLiveData()
    var group : MutableLiveData<Group> = MutableLiveData()
    var student : MutableLiveData<Student> = MutableLiveData()

    fun getGroupPosition(group: Group): Int = listOfGroup.value?.indexOfFirst {
        it.id==group.id
    } ?:-1

    fun getGroupPosition() = getGroupPosition(group.value?:Group())

    fun setCurrentGroup(position: Int){
        if(listOfGroup.value==null || position<0 ||
            (listOfGroup.value?.size!!<=position))
            return
        setCurrentGroup(listOfGroup.value!![position])

    }
    fun setCurrentGroup (_group:Group){
        group.postValue(_group)
    }

    fun addGroup(group:Group){
        myCoroutineScope.launch {
            universityDB.insertGroup(group)
            setCurrentGroup(group)
        }
    }

    fun updateGroup(group: Group){
        addGroup(group)
    }

    fun deleteGroup(group: Group){
        myCoroutineScope.launch { 
            universityDB.deleteGroup(group)
            setCurrentGroup(0)
        }
    }

    fun getStudentPosition(student: Student): Int = listOfStudent.value?.indexOfFirst {
        it.id==student.id
    } ?:-1

    fun getStudentPosition() = getStudentPosition(student.value?:Student())

    fun setCurrentStudent(position: Int){
        if(listOfStudent.value==null || position<0 ||
            (listOfStudent.value?.size!!<=position))
            return
        setCurrentStudent(listOfStudent.value!![position])

    }
    fun setCurrentStudent (_student:Student){
        student.postValue(_student)
    }

    fun addStudent(student:Student){
        myCoroutineScope.launch {
            universityDB.insertStudent(student)
            setCurrentStudent(student)
        }
    }

    fun updateStudent(student: Student){
        addStudent(student)
    }

    fun deleteStudent(student: Student){
        myCoroutineScope.launch {
            universityDB.deleteStudent(student)
            setCurrentStudent(0)
        }
    }
}