package com.example.pod_3.fragments

class StudentViewModel {
}