package com.example.meowapp27_02

import android.app.Application
import android.content.Context
import com.example.meowapp27_02.repository.UniversityRepository

class Application352: Application() {

    override fun onCreate() {
        super.onCreate()
        //UniversityRepository.getInstance().loadData()
    }

    init {
        instance = this
    }

    companion object {
        private var instance: Application352? = null

        val context
            get()= applicationContext()

        private fun applicationContext() : Context {
            return instance!!.applicationContext
        }
    }
}