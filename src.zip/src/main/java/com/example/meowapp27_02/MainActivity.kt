package com.example.meowapp27_02

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import com.example.meowapp27_02.data.Group
import com.example.meowapp27_02.data.Student
import com.example.meowapp27_02.fragments.FacultyListFragment
import com.example.meowapp27_02.fragments.GroupsFragment
import com.example.meowapp27_02.fragments.StudentFragment
import com.example.meowapp27_02.fragments.StudentsFragment
import com.example.meowapp27_02.fragments.StudentsViewModel
import com.example.meowapp27_02.fragments.UniversityListFragment
import com.example.meowapp27_02.fragments.UpdateActivity
import com.example.meowapp27_02.repository.UniversityRepository
//здесь всё что связано с фрагментами
class MainActivity : AppCompatActivity(), UpdateActivity {

    interface Edit {
        fun append()
        fun update()
        fun delete()
    }
    companion object{
        const val universityID = 0
        const val facultyID = 1
        const val groupID = 2
        const val studentID = 3
    }

    private var _miNewUniversity: MenuItem? = null
    private var _miUpdateUniversity: MenuItem? = null
    private var _miDeleteUniversity: MenuItem? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //supportFragmentManager
            //.beginTransaction()
            //.replace(R.id.fcwMain, UniversityListFragment.getInstance())
            //.commit()

        onBackPressedDispatcher.addCallback(this){
            if (supportFragmentManager.backStackEntryCount > 0) {
                supportFragmentManager.popBackStack()
                when (currentFragmentID){
                    universityID ->{
                        finish()
                    }
                    facultyID ->{
                        currentFragmentID = universityID
                        setTitle("Список университетов")
                    }
                    groupID -> {
                        currentFragmentID = facultyID
                        setTitle("Список факультетов")
                    }
                    else -> {}
                }
                updateMenuView()
            }
            else {
                finish()
            }
        }
        setFragment(universityID)


    }



//    override fun onStop() {
//        UniversityRepository.getInstance().saveData()
//        super.onStop()
//    }

    override fun setTitle(_title: String) {
        title = _title
    }

    private var currentFragmentID = -1

    override fun setFragment(fragmentID: Int, student: Student?) {
        currentFragmentID = fragmentID
        when (fragmentID){
            universityID ->{setFragment(UniversityListFragment.getInstance())}
            facultyID ->{setFragment(FacultyListFragment.getInstance())}
            groupID ->(setFragment(GroupsFragment.getInstance()))
            studentID -> {
                val group = UniversityRepository.getInstance().group.value
                    ?: throw IllegalStateException("Group not found")

                setFragment(StudentFragment.newInstance(group,student))
            }
        }
    }

    private fun updateMenuView(){
        _miUpdateUniversity?.isVisible = currentFragmentID == universityID
        _miDeleteUniversity?.isVisible = currentFragmentID == universityID
        _miNewUniversity?.isVisible = currentFragmentID == universityID
    }

    private fun setFragment(fragment: Fragment){
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fcwMain, fragment)
            .addToBackStack(null)
            .commit()
        updateMenuView()
    }

}