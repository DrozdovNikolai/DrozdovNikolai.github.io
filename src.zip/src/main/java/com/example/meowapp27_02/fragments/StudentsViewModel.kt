package com.example.meowapp27_02.fragments

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import com.example.meowapp27_02.data.Faculty
import com.example.meowapp27_02.data.FacultyList
import com.example.meowapp27_02.data.Group
import com.example.meowapp27_02.data.Student
import com.example.meowapp27_02.data.StudentList
import com.example.meowapp27_02.repository.UniversityRepository
import java.util.Date

class StudentsViewModel : ViewModel() {

    var studentList: MutableLiveData<List<Student>> = MutableLiveData()

    private var _student : Student? = null
    val student
        get() = _student

    var group : Group? = null


    fun set_Group(group: Group){
        this.group = group
        UniversityRepository.getInstance().listOfStudent.observeForever {
            studentList.postValue(
                it.filter { it.groupID == group.id } as MutableList<Student>
            )
        }
        UniversityRepository.getInstance().student.observeForever {
            _student = it
        }
    }

    fun deleteStudent(){
        if (student!= null)
            UniversityRepository.getInstance().deleteStudent(student!!)
    }

    
    fun updateStudent(lastName : String, firstName : String, middleName : String, birthDate: Date, phone:String, sex: Int){
        if (_student!=null){
            _student!!.lastName = lastName
            _student!!.firstName = firstName
            _student!!.middleName = middleName
            _student!!.birthDate = birthDate
            _student!!.phone = phone
            _student!!.sex = sex
            UniversityRepository.getInstance().updateStudent(_student!!)
        }
    }

    fun setCurrentStudent(student: Student){
        UniversityRepository.getInstance().setCurrentStudent(student)
    }
}