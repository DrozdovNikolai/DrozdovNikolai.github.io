package com.example.meowapp27_02.fragments

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import com.example.meowapp27_02.data.Faculty
import com.example.meowapp27_02.data.FacultyList
import com.example.meowapp27_02.data.University
import com.example.meowapp27_02.data.UniversityList
import com.example.meowapp27_02.repository.UniversityRepository

class FacultyListViewModel : ViewModel() {
    // TODO: Implement the ViewModel

    var facultyList: MutableLiveData<FacultyList?> = MutableLiveData()

    private var _faculty: Faculty?=null

    val faculty
        get() = _faculty

    val university
        get() = UniversityRepository.getInstance().university.value

    private val facultyListObserver = Observer<List<Faculty>> {
            list ->
        facultyList.postValue(FacultyList().apply {
            items = list?.filter { it.universityID==university?.id } as MutableList<Faculty>
        })
    }

    init {
        UniversityRepository.getInstance().facultyList.observeForever(facultyListObserver)

        UniversityRepository.getInstance().faculty.observeForever {
            _faculty=it
        }
    }

    fun deleteFaculty() {
        if (faculty!=null)
            UniversityRepository.getInstance().deleteFaculty(faculty!!)
    }

    fun appendFaculty(facultyName: String) {
        val faculty = Faculty()
        faculty.name=facultyName
        faculty.universityID=university?.id
        UniversityRepository.getInstance().newFaculty((faculty))
    }

    fun updateFaculty(facultyName: String){
        if (_faculty!=null){
            _faculty!!.name=facultyName
            UniversityRepository.getInstance().updateFaculty(_faculty!!)
        }
    }

    fun setCurrentFaculty(faculty: Faculty){
        Log.d("SET", "Faculty set: " + faculty.name)
        UniversityRepository.getInstance().setCurrentFaculty(faculty)
    }
}