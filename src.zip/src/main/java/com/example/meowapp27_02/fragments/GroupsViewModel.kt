package com.example.meowapp27_02.fragments

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.meowapp27_02.data.Group
import com.example.meowapp27_02.repository.UniversityRepository
import java.text.FieldPosition

class GroupsViewModel : ViewModel() {

    var groupList: MutableLiveData<List<Group>> = MutableLiveData()

    private var _group : Group? = null
    val group
        get() = _group

    init {
        UniversityRepository.getInstance().group.observeForever {
            _group = it
        }

        UniversityRepository.getInstance().listOfGroup.observeForever {
            groupList.postValue(
                it.filter { it.facultyID == UniversityRepository.getInstance().faculty.value?.id}.sortedBy { it.name } .toMutableList()
            )
        }
    }

    fun deleteGroup(){
        if (group != null)
            UniversityRepository.getInstance().deleteGroup(group!!)
    }

    val faculty
        get() = UniversityRepository.getInstance().faculty.value

    fun appendGroup(groupName : String){
        val group = Group()
        group.name = groupName
        group.facultyID = faculty?.id
        UniversityRepository.getInstance().addGroup(group)
    }

    fun updateGroup(groupName : String){
        if (_group != null){
            _group!!.name = groupName
            UniversityRepository.getInstance().updateGroup(_group!!)
        }
    }

    fun setCurrentGroup(position: Int){
        if ((groupList.value?.size ?: 0) > position)
            groupList.value?.let {UniversityRepository.getInstance().setCurrentGroup(it.get(position))}
    }

    fun setCurrentGroup(group: Group){
        UniversityRepository.getInstance().setCurrentGroup(group)
    }

    val getGroupPosition
        get() = groupList.value?.indexOfFirst { it.id == group?.id } ?: 1


}