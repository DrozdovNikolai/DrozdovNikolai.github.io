package com.example.meowapp27_02.fragments

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import com.example.meowapp27_02.data.Faculty
import com.example.meowapp27_02.data.University
import com.example.meowapp27_02.data.UniversityList
import com.example.meowapp27_02.repository.UniversityRepository

class UniversityListViewModel : ViewModel() {
    // TODO: Implement the ViewModel

    var universityList: LiveData<List<University>> = UniversityRepository.getInstance().universityList

    private var _university : University? = null

    val university
        get() = _university

//    private val universityListObserver = Observer<UniversityList?>{
//            list ->
//        universityList.postValue(list)
//
//    }

    init {
        //UniversityRepository.getInstance().universityList.observeForever(universityListObserver)
        UniversityRepository.getInstance().university.observeForever{
            _university = it
        }
    }

    fun deleteUniversity(){
        if (university != null)
            UniversityRepository.getInstance().deleteUniversity(university!!)
    }

    fun appendUniversity(universityName: String, universityCity: String){
        val university = University()
        university.name = universityName
        university.city = universityCity
        UniversityRepository.getInstance().newUniversity(university)
    }

    fun updateUniversity(universityName: String, universityCity: String){
        if (_university != null) {
            _university!!.name = universityName
            _university!!.city = universityCity
            UniversityRepository.getInstance().updateUniversity(_university!!)
        }
    }

    fun setCurrrentUniversity(university: University){
        Log.d("SET", "University set")
        UniversityRepository.getInstance().setCurrentUniversity(university)
    }

}