package com.example.meowapp27_02.fragments

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.meowapp27_02.MainActivity
import com.example.meowapp27_02.data.Faculty
import com.example.meowapp27_02.data.Group
import com.example.meowapp27_02.data.Student
import com.example.meowapp27_02.database.UniversityTypeConverter
import com.example.meowapp27_02.repository.UniversityRepository
import java.util.Date

class StudentViewModel : ViewModel() {

    var group : Group? = null

    val typeConverter = UniversityTypeConverter()

    fun appendStudent(lastName : String, firstName : String, middleName : String, birthDate: Date, phone:String, sex: Int){
        val student = Student()
        student.lastName = lastName
        student.firstName = firstName
        student.middleName = middleName
        student.birthDate = birthDate
        student.phone = phone
        student.sex = sex
        student.groupID = typeConverter.toUUID(MainActivity.groupID.toString())
        UniversityRepository.getInstance().addStudent(student)
    }
}