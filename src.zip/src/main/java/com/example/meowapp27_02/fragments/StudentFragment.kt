package com.example.meowapp27_02.fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.Spinner
import com.example.meowapp27_02.MainActivity
import com.example.meowapp27_02.R
import com.example.meowapp27_02.data.Group
import com.example.meowapp27_02.data.Student
import com.example.meowapp27_02.database.UniversityTypeConverter
import com.example.meowapp27_02.databinding.FragmentStudentBinding
import com.example.meowapp27_02.repository.UniversityRepository
import java.util.Calendar
import java.util.Date

class StudentFragment : Fragment() {

    private lateinit var group: Group
    private lateinit var student: Student

    companion object {
        fun newInstance(group: Group, student: Student?) : StudentFragment {
            return StudentFragment().apply {
                this.group=group
                this.student=student!!
            }
        }
    }

    private lateinit var viewModel: StudentViewModel
    private lateinit var binding: FragmentStudentBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentStudentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this).get(StudentViewModel::class.java)

        val etSurname = view.findViewById<EditText>(R.id.etSurname)
        val etFirstName = view.findViewById<EditText>(R.id.etFirstName)
        val etMiddleName = view.findViewById<EditText>(R.id.etMiddleName)
        val etPhone = view.findViewById<EditText>(R.id.etPhone)
        val spSex = view.findViewById<Spinner>(R.id.spSex)
        val cwBirthDate = view.findViewById<CalendarView>(R.id.cwBirthDate)

        etSurname.setText(student.lastName)

        var birthDate: Long = System.currentTimeMillis()

        cwBirthDate.setOnDateChangeListener { view, year, month, dayOfMonth ->
            val calendar = Calendar.getInstance()
            calendar.set(year, month, dayOfMonth)
            birthDate = calendar.timeInMillis
        }

        val typeConverter = UniversityTypeConverter()

        binding.btnSave.setOnClickListener{

            val student = Student()
            student.lastName = etSurname.text.toString()
            student.firstName = etFirstName.text.toString()
            student.middleName = etMiddleName.text.toString()
            student.birthDate = typeConverter.toDate(birthDate)!!
            student.phone = etPhone.text.toString()
            student.sex = spSex.selectedItemPosition
            student.groupID = group.id

            Log.d("INTESTMEOW",etSurname.toString())
            Log.d("INTESTMEOW",student.firstName)
            Log.d("INTESTMEOW",student.middleName)
            Log.d("INTESTMEOW",student.birthDate.toString())
            Log.d("INTESTMEOW",student.phone)
            Log.d("INTESTMEOW",student.sex.toString())
            Log.d("INTESTMEOW",student.groupID.toString())


            UniversityRepository.getInstance().addStudent(student)
            parentFragmentManager.popBackStack()
        }
        binding.btnCancel.setOnClickListener{
            parentFragmentManager.popBackStack()
        }
    }

}