package com.example.meowapp27_02.fragments

import com.example.meowapp27_02.data.Student

interface UpdateActivity {
    fun setTitle(_title: String)
    fun setFragment(fragmentID : Int, student: Student?=null)

}