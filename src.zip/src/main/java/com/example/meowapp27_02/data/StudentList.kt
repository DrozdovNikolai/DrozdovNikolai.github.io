package com.example.meowapp27_02.data

data class StudentList(
    var items : MutableList<Faculty> = mutableListOf()
)
