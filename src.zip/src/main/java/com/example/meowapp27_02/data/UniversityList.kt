package com.example.meowapp27_02.data

data class UniversityList(
    var items : MutableList<University> = mutableListOf()
)

