package com.example.meowapp27_02.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.meowapp27_02.data.Faculty
import com.example.meowapp27_02.data.Group
import com.example.meowapp27_02.data.Student
import com.example.meowapp27_02.data.University

@Database(
    entities = [University::class,
                Faculty::class,
        Group::class,
        Student::class],
    version = 1,
    exportSchema = false
)

@TypeConverters(UniversityTypeConverter::class)

abstract class UniversityDB : RoomDatabase() {
    abstract fun universityDAO(): UniversityDAO

    companion object {
        @Volatile
        private var INSTANCE: UniversityDB? = null

        fun getDatabase(context: Context): UniversityDB {
            return INSTANCE ?: synchronized(this) {
                buildDatabase(context).also { INSTANCE = it}
            }
        }

        private fun buildDatabase(context: Context) = Room.databaseBuilder(
            context,
            UniversityDB::class.java,
            "university_database")
            .fallbackToDestructiveMigration()
            .build()
    }
}